# pieces-MEWS

This library was generated with [Nx](https://nx.dev).

## Building

Run `nx build pieces-MEWS` to build the library.
